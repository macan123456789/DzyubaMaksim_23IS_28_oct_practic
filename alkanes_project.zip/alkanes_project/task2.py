import tkinter as tk
from tkinter import ttk
import psycopg2


def очистить_таблицу():
    for строка in таблица.get_children():
        таблица.delete(строка)


def показать_алканы():
    with psycopg2.connect(
        dbname="alkenes_task2",
        user="postgres",
        password="1111",
        host="localhost",
        port=5432,
        connect_timeout=5
    ) as соединение:
        with соединение.cursor() as курсор:
            курсор.execute("""
                SELECT name, formula, carbon_count, hydrogen_count, molar_mass
                FROM public.alkanes
                ORDER BY carbon_count ASC
            """)
            алканы = курсор.fetchall()

    очистить_таблицу()

    for алкан in алканы:
        название = алкан[0]
        формула = алкан[1]
        число_атомов = алкан[2]
        число_атомовв = алкан[3]
        масса = алкан[4]

        таблица.insert("", tk.END, values=(название, формула, число_атомов, число_атомовв, масса ))


окно = tk.Tk()
окно.title("Каталог: Алканы")
окно.geometry("680x420")

надпись = ttk.Label(окно, text="Каталог: Алканы")
надпись.pack(pady=10)

кнопка_показать = ttk.Button(
    окно,
    text="Показать",
    command=показать_алканы
)
кнопка_показать.pack(pady=5)

кнопка_очистки = ttk.Button(
    окно,
    text="Очистить таблицу",
    command=очистить_таблицу
)
кнопка_очистки.pack(pady=5)

таблица = ttk.Treeview(
    окно,
    columns=("name", "formula", "carbon_count", "hydrogen_count", "molar_mass"),
    show="headings",
    height=10
)
таблица.heading("name", text="Название", )
таблица.heading("formula", text="Формула")
таблица.heading("carbon_count", text="Атомов C")
таблица.heading("hydrogen_count", text="Атомов H")
таблица.heading("molar_mass", text="г/моль")

таблица.column("name", width=22, anchor="w")
таблица.column("formula", width=16, anchor="center")
таблица.column("carbon_count", width=18, anchor="center")
таблица.column("hydrogen_count", width=18, anchor="center")
таблица.column("molar_mass", width=18, anchor="center")

таблица.pack(padx=15, pady=10, fill="both", expand=True)
table_frame = ttk.Frame(окно)
table_frame.pack(fill="both", expand=True)

scrollbar = ttk.Scrollbar(
    table_frame,
    orient=tk.VERTICAL,
    command=таблица.yview
)
таблица.configure(yscrollcommand=scrollbar.set)

таблица.pack(side="left", fill="x")
scrollbar.pack(side="right", fill="y")


окно.mainloop()
