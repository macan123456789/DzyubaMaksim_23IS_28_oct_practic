import psycopg2

min = 7
with psycopg2.connect(
    dbname="organic_chemistry",
    user="postgres",
    password="1111",
    host="localhost",
    port=5432,
    connect_timeout=5
) as connected:
    with connected.cursor() as cursor:
        cursor.execute("""
            SELECT name, formula, carbon_count
            FROM public.alkanes
            WHERE carbon_count >= %s
            ORDER BY carbon_count ASC
        """, (min,))
        alkans = cursor.fetchall()

for alkan in alkans:
    name = alkan[0]
    formula = alkan[1]
    carbon_count = alkan[2]
    print(name, formula, carbon_count)