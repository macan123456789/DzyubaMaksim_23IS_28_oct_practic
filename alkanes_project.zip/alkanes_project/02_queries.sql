SELECT name, formula, carbon_count
FROM public.alkanes
ORDER BY carbon_count ASC;